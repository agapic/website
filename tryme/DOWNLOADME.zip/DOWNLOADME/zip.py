import zipfile
import optparse
import os
from threading import *

def extractFile(zipFile, password):


def main():


if __name__ == '__main__':
    main()
